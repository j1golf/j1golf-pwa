// ============================================
// 韩选高尔夫 PWA - JavaScript
// HANSELECT GOLF PWA App Logic
// ============================================

const app = {

  // ===== 상태 관리 =====
  state: {
    currentPage: 'home',
    currentTab: 'home',
    selectedBrand: '',
    sortType: 'hot',
    cart: [],
    products: [],
    proProducts: [],
    page: 1,
    hasMore: true,
    isOnline: navigator.onLine
  },

  // ===== 초기화 =====
  init() {
    this.loadData();
    this.renderHome();
    this.setupEventListeners();
    this.setupBanner();
    this.checkOnlineStatus();

    console.log('韩选高尔夫 PWA initialized');
  },

  // ===== 데이터 로드 =====
  loadData() {
    // 프로 추천 상품
    this.state.proProducts = [
      {
        id: 'p001',
        name: 'TaylorMade SIM2 Driver 10.5°',
        brand: 'TaylorMade',
        price: 2800,
        originalPrice: 5800,
        image: 'https://images.unsplash.com/photo-1535131749006-b7f58c99034b?w=400',
        grade: 'A',
        gradeText: 'A级',
        proName: '金教练',
        proAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100'
      },
      {
        id: 'p002',
        name: 'Callaway Rogue ST Iron 6-PW',
        brand: 'Callaway',
        price: 3200,
        originalPrice: 7200,
        image: 'https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?w=400',
        grade: 'S',
        gradeText: 'S级',
        proName: '李教练',
        proAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100'
      },
      {
        id: 'p003',
        name: 'Titleist Vokey SM8 56°',
        brand: 'Titleist',
        price: 1200,
        originalPrice: 2400,
        image: 'https://images.unsplash.com/photo-1591491640784-3232eb6e8c41?w=400',
        grade: 'A',
        gradeText: 'A级',
        proName: '朴教练',
        proAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100'
      },
      {
        id: 'p004',
        name: 'Ping G425 Driver 9°',
        brand: 'Ping',
        price: 3500,
        originalPrice: 6500,
        image: 'https://images.unsplash.com/photo-1623934199716-dc28818a6ec7?w=400',
        grade: 'S',
        gradeText: 'S级',
        proName: '金教练',
        proAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100'
      }
    ];

    // 전체 상품
    this.state.products = [
      {
        id: '001',
        name: 'TaylorMade SIM2 Max Driver 10.5° Regular Flex',
        brand: 'TaylorMade',
        price: 2800,
        originalPrice: 5800,
        image: 'https://images.unsplash.com/photo-1535131749006-b7f58c99034b?w=400',
        grade: 'A',
        gradeText: 'A级',
        flex: 'R',
        loft: '10.5°',
        isNew: true,
        isHot: true,
        isProRecommended: true
      },
      {
        id: '002',
        name: 'Callaway Rogue ST Max Iron Set 5-PW Steel',
        brand: 'Callaway',
        price: 3200,
        originalPrice: 7200,
        image: 'https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?w=400',
        grade: 'S',
        gradeText: 'S级',
        flex: 'S200',
        isNew: false,
        isHot: true,
        isProRecommended: false
      },
      {
        id: '003',
        name: 'Titleist TSi2 Driver 9° Stiff Flex',
        brand: 'Titleist',
        price: 3600,
        originalPrice: 6800,
        image: 'https://images.unsplash.com/photo-1591491640784-3232eb6e8c41?w=400',
        grade: 'A',
        gradeText: 'A级',
        flex: 'S',
        loft: '9°',
        isNew: true,
        isHot: false,
        isProRecommended: true
      },
      {
        id: '004',
        name: 'Ping G425 Max Fairway Wood 3W 14.5°',
        brand: 'Ping',
        price: 1800,
        originalPrice: 3800,
        image: 'https://images.unsplash.com/photo-1623934199716-dc28818a6ec7?w=400',
        grade: 'B',
        gradeText: 'B级',
        flex: 'R',
        loft: '14.5°',
        isNew: false,
        isHot: false,
        isProRecommended: false
      },
      {
        id: '005',
        name: 'Mizuno JPX 921 Hot Metal Iron 6-GW',
        brand: 'Mizuno',
        price: 2600,
        originalPrice: 5500,
        image: 'https://images.unsplash.com/photo-1535131749006-b7f58c99034b?w=400',
        grade: 'A',
        gradeText: 'A级',
        flex: 'R300',
        isNew: false,
        isHot: true,
        isProRecommended: true
      },
      {
        id: '006',
        name: 'PXG 0311 P Gen4 Iron Set 4-PW',
        brand: 'PXG',
        price: 4800,
        originalPrice: 12000,
        image: 'https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?w=400',
        grade: 'S',
        gradeText: 'S级',
        flex: 'S',
        isNew: true,
        isHot: false,
        isProRecommended: false
      }
    ];
  },

  // ===== 홈 화면 렌더링 =====
  renderHome() {
    this.renderProProducts();
    this.renderProducts();
  },

  // ===== 프로 추천 렌더링 =====
  renderProProducts() {
    const container = document.getElementById('pro-list');
    if (!container) return;

    container.innerHTML = this.state.proProducts.map(item => `
      <div class="pro-card" onclick="app.goToDetail('${item.id}')">
        <div class="pro-image-wrap">
          <img src="${item.image}" alt="${item.name}" loading="lazy">
          <div class="pro-overlay">
            <img class="pro-avatar" src="${item.proAvatar}" alt="${item.proName}">
            <span class="pro-name">${item.proName}</span>
          </div>
        </div>
        <div class="pro-info">
          <div class="pro-product-name">${item.name}</div>
          <div class="pro-product-brand">${item.brand}</div>
          <div class="pro-price-row">
            <span class="pro-price">¥${item.price}</span>
            <span class="pro-original">¥${item.originalPrice}</span>
          </div>
          <div class="pro-tags">
            <span class="tag grade-${item.grade}">${item.gradeText}</span>
            <span class="tag pro-recommend">教练推荐</span>
          </div>
        </div>
      </div>
    `).join('');
  },

  // ===== 상품 리스트 렌더링 =====
  renderProducts() {
    const container = document.getElementById('product-grid');
    if (!container) return;

    let products = this.state.products;

    // 브랜드 필터
    if (this.state.selectedBrand) {
      products = products.filter(p => p.brand === this.state.selectedBrand);
    }

    // 정렬
    products = this.sortProducts(products);

    container.innerHTML = products.map(item => `
      <div class="product-card" onclick="app.goToDetail('${item.id}')">
        <div class="product-image-wrap">
          <img src="${item.image}" alt="${item.name}" loading="lazy">
          ${item.isNew ? '<span class="product-badge">NEW</span>' : ''}
          ${item.isHot ? '<span class="product-badge hot">HOT</span>' : ''}
        </div>
        <div class="product-info">
          <div class="product-brand">${item.brand}</div>
          <div class="product-name">${item.name}</div>
          <div class="product-specs">
            ${item.flex ? `<span class="spec-item">${item.flex}</span>` : ''}
            ${item.loft ? `<span class="spec-item">${item.loft}</span>` : ''}
          </div>
          <div class="product-price-row">
            <span class="product-price">¥${item.price}</span>
            <span class="product-original">¥${item.originalPrice}</span>
          </div>
          <div class="product-bottom">
            <div class="product-tags">
              <span class="tag grade-${item.grade}">${item.gradeText}</span>
              ${item.isProRecommended ? '<span class="tag pro-tag">教练验</span>' : ''}
            </div>
            <div class="product-shipping">🇰🇷 韩国直邮</div>
          </div>
        </div>
      </div>
    `).join('');
  },

  // ===== 정렬 =====
  sortProducts(products) {
    const sorted = [...products];
    switch(this.state.sortType) {
      case 'hot':
        return sorted.sort((a, b) => (b.isHot ? 1 : 0) - (a.isHot ? 1 : 0));
      case 'new':
        return sorted.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
      case 'price-asc':
        return sorted.sort((a, b) => a.price - b.price);
      case 'price-desc':
        return sorted.sort((a, b) => b.price - a.price);
      default:
        return sorted;
    }
  },

  // ===== 배너 설정 =====
  setupBanner() {
    const slides = document.querySelectorAll('.banner-slide');
    const dots = document.querySelectorAll('.dot');
    let current = 0;

    setInterval(() => {
      slides[current].classList.remove('active');
      dots[current].classList.remove('active');

      current = (current + 1) % slides.length;

      slides[current].classList.add('active');
      dots[current].classList.add('active');
    }, 4000);
  },

  // ===== 이벤트 리스너 =====
  setupEventListeners() {
    // 온라인/오프라인 감지
    window.addEventListener('online', () => {
      this.state.isOnline = true;
      document.getElementById('offline-banner').classList.remove('show');
    });

    window.addEventListener('offline', () => {
      this.state.isOnline = false;
      document.getElementById('offline-banner').classList.add('show');
    });

    // 터치 스와이프 (향상된 UX)
    let touchStartX = 0;
    const main = document.querySelector('.app-main');

    main.addEventListener('touchstart', (e) => {
      touchStartX = e.touches[0].clientX;
    });

    main.addEventListener('touchend', (e) => {
      const touchEndX = e.changedTouches[0].clientX;
      const diff = touchStartX - touchEndX;

      // 좌우 스와이프로 페이지 뒤로가기 (선택적)
      if (Math.abs(diff) > 100 && this.state.currentPage !== 'home') {
        if (diff < 0) { // 오른쪽으로 스와이프
          this.goBack();
        }
      }
    });
  },

  // ===== 탭 전환 =====
  switchTab(tabName) {
    // 탭 UI 업데이트
    document.querySelectorAll('.tab-item').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.page === tabName);
    });

    this.state.currentTab = tabName;

    // 페이지 전환
    switch(tabName) {
      case 'home':
        this.showPage('home-page');
        break;
      case 'category':
        this.showPage('category-page');
        this.renderCategory();
        break;
      case 'cart':
        this.showPage('cart-page');
        this.renderCart();
        break;
      case 'profile':
        this.showPage('profile-page');
        break;
    }
  },

  // ===== 페이지 표시 =====
  showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
      page.classList.remove('active');
    });

    const target = document.getElementById(pageId);
    if (target) {
      target.classList.add('active');
      this.state.currentPage = pageId;
    }

    // 스크롤 맨 위로
    window.scrollTo(0, 0);
  },

  // ===== 뒤로가기 =====
  goBack() {
    this.showPage('home-page');

    // 탭바 업데이트
    document.querySelectorAll('.tab-item').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.page === 'home');
    });
  },

  // ===== 상품 상세 =====
  goToDetail(productId) {
    const product = [...this.state.products, ...this.state.proProducts]
      .find(p => p.id === productId);

    if (!product) return;

    const content = document.getElementById('detail-content');
    content.innerHTML = `
      <div class="detail-gallery">
        <img src="${product.image}" alt="${product.name}">
      </div>
      <div class="detail-info">
        <h1>${product.name}</h1>
        <div class="detail-brand">${product.brand}</div>
        <div class="detail-price-row">
          <span class="detail-price">¥${product.price}</span>
          <span class="detail-original">¥${product.originalPrice}</span>
        </div>
        <div class="detail-tags">
          <span class="tag grade-${product.grade}">${product.gradeText}</span>
          ${product.isProRecommended ? '<span class="tag pro-tag">教练验</span>' : ''}
        </div>
        <div class="detail-shipping">🇰🇷 韩国直邮 · 预计7-14天送达</div>
        <button class="buy-btn" onclick="app.addToCart('${product.id}')">加入购物车</button>
      </div>
    `;

    this.showPage('detail-page');
  },

  // ===== 카테고리 =====
  goToCategory(type) {
    this.switchTab('category');
  },

  renderCategory() {
    const container = document.getElementById('category-products');
    container.innerHTML = '<p style="padding: 40px; text-align: center; color: #999;">分类页面开发中...</p>';
  },

  // ===== 검색 =====
  goToSearch() {
    alert('搜索功能开发中...');
  },

  // ===== 프로 페이지 =====
  goToProPage() {
    alert('教练页面开发中...');
  },

  // ===== 브랜드 필터 =====
  filterByBrand(brand) {
    this.state.selectedBrand = brand;

    // UI 업데이트
    document.querySelectorAll('.brand-tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.brand === brand);
    });

    this.renderProducts();
  },

  // ===== 정렬 변경 =====
  changeSort(type) {
    this.state.sortType = type;

    // UI 업데이트
    document.querySelectorAll('.sort-item').forEach(item => {
      item.classList.toggle('active', item.dataset.sort === type);
    });

    this.renderProducts();
  },

  // ===== 장바구니 =====
  addToCart(productId) {
    const product = [...this.state.products, ...this.state.proProducts]
      .find(p => p.id === productId);

    if (!product) return;

    this.state.cart.push(product);
    this.updateCartBadge();

    // 토스트 알림
    this.showToast('已加入购物车');
  },

  renderCart() {
    const container = document.getElementById('cart-content');

    if (this.state.cart.length === 0) {
      container.innerHTML = `
        <div style="padding: 60px 20px; text-align: center; color: #999;">
          <div style="font-size: 48px; margin-bottom: 16px;">🛒</div>
          <p>购物车是空的</p>
          <button onclick="app.switchTab('home')" style="margin-top: 20px; padding: 10px 24px; background: #111; color: #fff; border: none; border-radius: 20px;">去逛逛</button>
        </div>
      `;
      return;
    }

    const total = this.state.cart.reduce((sum, item) => sum + item.price, 0);

    container.innerHTML = `
      <div class="cart-list">
        ${this.state.cart.map((item, index) => `
          <div class="cart-item">
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-info">
              <div class="cart-item-name">${item.name}</div>
              <div class="cart-item-price">¥${item.price}</div>
            </div>
            <button onclick="app.removeFromCart(${index})" style="background: none; border: none; color: #999; font-size: 20px;">×</button>
          </div>
        `).join('')}
      </div>
      <div class="cart-footer">
        <div class="cart-total">合计: ¥${total}</div>
        <button class="checkout-btn" onclick="app.checkout()">结算</button>
      </div>
    `;
  },

  removeFromCart(index) {
    this.state.cart.splice(index, 1);
    this.updateCartBadge();
    this.renderCart();
  },

  updateCartBadge() {
    const badge = document.getElementById('cart-badge');
    if (badge) {
      badge.textContent = this.state.cart.length;
      badge.style.display = this.state.cart.length > 0 ? 'flex' : 'none';
    }
  },

  checkout() {
    alert('结算功能开发中...');
  },

  // ===== 프로필 페이지 =====
  goToOrders() { alert('订单页面开发中...'); },
  goToAddress() { alert('地址页面开发中...'); },
  goToFavorites() { alert('收藏页面开发中...'); },
  goToService() { alert('客服页面开发中...'); },

  // ===== 공유 =====
  share() {
    if (navigator.share) {
      navigator.share({
        title: '韩选高尔夫',
        text: '韩国精选二手高尔夫用品，教练验货直邮中国',
        url: window.location.href
      });
    } else {
      alert('请复制链接分享');
    }
  },

  // ===== 더 불러오기 =====
  loadMore() {
    this.showToast('加载中...');
    setTimeout(() => {
      this.state.hasMore = false;
      document.getElementById('load-more').innerHTML = '<p style="color: #999; padding: 20px;">已经到底了</p>';
    }, 1000);
  },

  // ===== 토스트 알림 =====
  showToast(message) {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(0,0,0,0.8);
      color: #fff;
      padding: 12px 24px;
      border-radius: 8px;
      font-size: 14px;
      z-index: 10000;
      animation: fadeIn 0.3s ease;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 2000);
  },

  // ===== 온라인 상태 체크 =====
  checkOnlineStatus() {
    if (!this.state.isOnline) {
      document.getElementById('offline-banner').classList.add('show');
    }
  }

};

// ===== 앱 시작 =====
document.addEventListener('DOMContentLoaded', () => {
  app.init();
});