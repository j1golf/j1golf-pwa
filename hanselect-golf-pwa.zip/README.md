# 韩选高尔夫 (HANSELECT GOLF) - PWA

## 프로젝트 개요
- **브랜드명**: 韩选高尔夫 (HANSELECT GOLF / 한 쉬 안 골프)
- **설명**: 韩国精选二手高尔夫用品，教练验货直邮中国
- **플랫폼**: Progressive Web App (PWA)

## 파일 구조
```
hanselect-golf-pwa/
├── index.html          # 메인 HTML
├── manifest.json       # PWA 설정
├── sw.js               # Service Worker (오프라인 캐싱)
├── css/
│   └── style.css       # 스타일시트
├── js/
│   └── app.js          # 앱 로직
└── icons/              # 아이콘 파일들
    ├── icon-72x72.png
    ├── icon-96x96.png
    ├── icon-128x128.png
    ├── icon-144x144.png
    ├── icon-152x152.png
    ├── icon-192x192.png
    ├── icon-384x384.png
    └── icon-512x512.png
```

## 실행 방법

### 로컬 테스트
1. VS Code 설치
2. Live Server 확장 프로그램 설치
3. 프로젝트 폴더 열기
4. `index.html` 우클릭 → `Open with Live Server`
5. 브라우저에서 `http://localhost:5500` 접속

### PWA 기능 확인
1. Chrome 개발자 도구 (F12)
2. `Application` 탭 선택
3. `Manifest`, `Service Workers`, `Cache Storage` 확인
4. `Add to Home Screen` 버튼으로 설치 테스트

### 배포
- 정적 웹 호스팅: Vercel, Netlify, GitHub Pages, 腾讯云 COS 등
- HTTPS 필수 (PWA 기능 사용을 위해)

## 주요 기능
- ✅ 반응형 디자인 (모바일 최적화)
- ✅ 오프라인 캐싱 (Service Worker)
- ✅ 홈 화면 설치 (PWA)
- ✅ 상품 목록/상세/장바구니
- ✅ 브랜드 필터/정렬
- ✅ 프로 추천 상품
- ✅ 터치 스와이프 지원

## 주의사항
- 아이콘 파일 (`icons/`)은 실제 디자인된 PNG 파일로 교체 필요
- 현재 샘플 데이터 사용 중 → 실제 API 연동 필요
- 결제 기능은 별도 연동 필요 (알리페이, 위챗 페이 등)

## 브랜드 컬러
- Primary: #111111 (블랙)
- Gold: #C8A25D (골드)
- Gray: #888888 (그레이)

---
韩选高尔夫 - 让每一位高尔夫爱好者，放心选择，安心使用。
